from flask import Flask, render_template, request, jsonify, url_for, send_from_directory
from werkzeug.utils import secure_filename
import os
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-in-production'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Allowed extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

# Create upload folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Product categories with default images
PRODUCT_CATEGORIES = {
    'engine': {
        'title': 'Двигатель и компоненты',
        'description': 'Оригинальные запчасти для двигателей HOWO',
        'image': 'catalog_engine.png',
        'icon': '🔩',
        'features': ['Гарантия', 'В наличии']
    },
    'transmission': {
        'title': 'Трансмиссия',
        'description': 'КПП, сцепление, карданные валы',
        'image': 'catalog_transmission.png',
        'icon': '⚙️',
        'features': ['Качество', 'Доставка']
    },
    'chassis': {
        'title': 'Ходовая часть',
        'description': 'Амортизаторы, рессоры, ступицы',
        'image': 'catalog_chassis.png',
        'icon': '🛞',
        'features': ['Надежность', 'Монтаж']
    },
    'brakes': {
        'title': 'Тормозная система',
        'description': 'Колодки, диски, барабаны',
        'image': 'catalog_brakes.png',
        'icon': '🔧',
        'features': ['Безопасность', 'Тесты']
    },
    'cooling': {
        'title': 'Система охлаждения',
        'description': 'Радиаторы, помпы, термостаты',
        'image': 'catalog_cooling.png',
        'icon': '💨',
        'features': ['Эффективность', 'Гарантия']
    },
    'electric': {
        'title': 'Электрика',
        'description': 'Стартеры, генераторы, датчики',
        'image': 'catalog_electric.png',
        'icon': '⚡',
        'features': ['Диагностика', 'Установка']
    },
    'antifreeze': {
        'title': 'Антифриз',
        'description': 'Охлаждающие жидкости для всех типов двигателей',
        'image': 'catalog_antifreeze.png',
        'icon': '🧊',
        'features': ['Всесезонный', 'Защита']
    },
    'oil': {
        'title': 'Моторное масло',
        'description': 'Масла для дизельных и бензиновых двигателей',
        'image': 'catalog_oil.png',
        'icon': '🛢️',
        'features': ['Синтетика', 'Минеральное']
    },
    'bearings': {
        'title': 'Подшипники',
        'description': 'Подшипники для всех узлов и агрегатов',
        'image': 'catalog_bearings.png',
        'icon': '⚪',
        'features': ['Точность', 'Долговечность']
    }
}

SERVICE_INFO = {
    'vulcanization': {
        'title': 'Профессиональная вулканизация',
        'description': 'Современное оборудование для ремонта шин всех типов транспорта',
        'image': 'catalog_vulkanizatsiya.png',
        'icon': '🛞'
    }
}

# Tire products data
TIRE_PRODUCTS = {
    'michelin_175': {
        'brand': 'Michelin',
        'model': 'X Multi',
        'size': '17.5',
        'full_size': '215/75 R17.5',
        'description': 'Премиальные шины для магистральных перевозок',
        'features': ['Всесезонные', 'Увеличенный пробег', 'Экономия топлива'],
        'image': 'tire_michelin_175.png',
        'price': 'По звонку'
    },
    'michelin_225': {
        'brand': 'Michelin',
        'model': 'X Line Energy',
        'size': '22.5',
        'full_size': '315/80 R22.5',
        'description': 'Шины для дальних перевозок с низким расходом топлива',
        'features': ['Магистральные', 'Долговечность', 'Комфорт'],
        'image': 'tire_michelin_225.png',
        'price': 'По звонку'
    },
    'kama_175': {
        'brand': 'KAMA',
        'model': 'NF-202',
        'size': '17.5',
        'full_size': '235/75 R17.5',
        'description': 'Надежные российские шины для грузовиков',
        'features': ['Всесезонные', 'Усиленный каркас', 'Для СНГ'],
        'image': 'tire_kama_175.png',
        'price': 'По звонку'
    },
    'kama_225': {
        'brand': 'KAMA',
        'model': 'NR-201',
        'size': '22.5',
        'full_size': '295/80 R22.5',
        'description': 'Проверенные временем шины для российских дорог',
        'features': ['Выносливость', 'Ремонтопригодность', 'Цена-качество'],
        'image': 'tire_kama_225.png',
        'price': 'По звонку'
    },
    'omsk_175': {
        'brand': 'OMSKRUSSIA',
        'model': 'Professional',
        'size': '17.5',
        'full_size': '245/70 R17.5',
        'description': 'Шины от Омского шинного завода',
        'features': ['Для региональных перевозок', 'Прочность', 'Гарантия'],
        'image': 'tire_omsk_175.png',
        'price': 'По звонку'
    },
    'omsk_225': {
        'brand': 'OMSKRUSSIA',
        'model': 'Magistral',
        'size': '22.5',
        'full_size': '315/70 R22.5',
        'description': 'Магистральные шины российского производства',
        'features': ['Износостойкость', 'Всесезонность', 'Надежность'],
        'image': 'tire_omsk_225.png',
        'price': 'По звонку'
    },
    'durable_175': {
        'brand': 'DURABLE',
        'model': 'DR755',
        'size': '17.5',
        'full_size': '215/75 R17.5',
        'description': 'Китайские шины оптимального качества',
        'features': ['Бюджетный вариант', 'Хорошее сцепление', 'Износостойкость'],
        'image': 'tire_durable_175.png',
        'price': 'По звонку'
    },
    'durable_225': {
        'brand': 'DURABLE',
        'model': 'DR766',
        'size': '22.5',
        'full_size': '295/80 R22.5',
        'description': 'Доступные шины для грузового транспорта',
        'features': ['Экономичность', 'Универсальность', 'Доступная цена'],
        'image': 'tire_durable_225.png',
        'price': 'По звонку'
    },
    'sailun_175': {
        'brand': 'Sailun',
        'model': 'S737',
        'size': '17.5',
        'full_size': '235/75 R17.5',
        'description': 'Современные китайские шины премиум-класса',
        'features': ['Тихий ход', 'Экономия топлива', 'Современные технологии'],
        'image': 'tire_sailun_175.png',
        'price': 'По звонку'
    },
    'sailun_225': {
        'brand': 'Sailun',
        'model': 'S757',
        'size': '22.5',
        'full_size': '315/80 R22.5',
        'description': 'Шины с отличным соотношением цена-качество',
        'features': ['Долговечность', 'Комфорт', 'Гарантия качества'],
        'image': 'tire_sailun_225.png',
        'price': 'По звонку'
    }
}

@app.route('/')
def index():
    return render_template('index.html', 
                         products=PRODUCT_CATEGORIES,
                         service=SERVICE_INFO)

@app.route('/tires')
def tires():
    return render_template('tires.html', 
                         tires=TIRE_PRODUCTS)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    category = request.form.get('category', 'general')
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        # Create unique filename
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = secure_filename(file.filename)
        name, ext = os.path.splitext(filename)
        new_filename = f"{category}_{timestamp}{ext}"
        
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], new_filename)
        file.save(filepath)
        
        # Update category image
        if category in PRODUCT_CATEGORIES:
            PRODUCT_CATEGORIES[category]['image'] = new_filename
        elif category == 'vulcanization':
            SERVICE_INFO['vulcanization']['image'] = new_filename
        
        return jsonify({
            'success': True,
            'filename': new_filename,
            'url': url_for('static', filename=f'uploads/{new_filename}')
        })
    
    return jsonify({'error': 'Invalid file type'}), 400

@app.route('/api/contact', methods=['POST'])
def contact():
    """Handle contact form submissions"""
    data = request.get_json()
    
    # Here you can add email sending logic or save to database
    # For now, we'll just return success
    
    print(f"New contact request: {data}")
    
    return jsonify({
        'success': True,
        'message': 'Ваша заявка принята! Мы свяжемся с вами в ближайшее время.'
    })

@app.errorhandler(404)
def not_found(error):
    return render_template('index.html'), 404

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)