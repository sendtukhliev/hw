from flask import Flask, render_template, request, jsonify, url_for, send_from_directory
from werkzeug.utils import secure_filename
import os
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-in-production'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Allowed extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

# Create upload folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Product categories with default images
PRODUCT_CATEGORIES = {
    'engine': {
        'title': 'Двигатель и компоненты',
        'description': 'Оригинальные запчасти для двигателей HOWO',
        'image': 'catalog_engine.png',
        'icon': '🔩',
        'features': ['Гарантия', 'В наличии']
    },
    'transmission': {
        'title': 'Трансмиссия',
        'description': 'КПП, сцепление, карданные валы',
        'image': 'catalog_transmission.png',
        'icon': '⚙️',
        'features': ['Качество', 'Доставка']
    },
    'chassis': {
        'title': 'Ходовая часть',
        'description': 'Амортизаторы, рессоры, ступицы',
        'image': 'catalog_chassis.png',
        'icon': '🛞',
        'features': ['Надежность', 'Монтаж']
    },
    'brakes': {
        'title': 'Тормозная система',
        'description': 'Колодки, диски, барабаны',
        'image': 'catalog_brakes.png',
        'icon': '🔧',
        'features': ['Безопасность', 'Тесты']
    },
    'cooling': {
        'title': 'Система охлаждения',
        'description': 'Радиаторы, помпы, термостаты',
        'image': 'catalog_cooling.png',
        'icon': '💨',
        'features': ['Эффективность', 'Гарантия']
    },
    'electric': {
        'title': 'Электрика',
        'description': 'Стартеры, генераторы, датчики',
        'image': 'catalog_electric.png',
        'icon': '⚡',
        'features': ['Диагностика', 'Установка']
    }
}

SERVICE_INFO = {
    'vulcanization': {
        'title': 'Профессиональная вулканизация',
        'description': 'Современное оборудование для ремонта шин всех типов транспорта',
        'image': 'catalog_vulkanizatsiya.png',
        'icon': '🛞'
    }
}

@app.route('/')
def index():
    return render_template('index.html', 
                         products=PRODUCT_CATEGORIES,
                         service=SERVICE_INFO)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    category = request.form.get('category', 'general')
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        # Create unique filename
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = secure_filename(file.filename)
        name, ext = os.path.splitext(filename)
        new_filename = f"{category}_{timestamp}{ext}"
        
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], new_filename)
        file.save(filepath)
        
        # Update category image
        if category in PRODUCT_CATEGORIES:
            PRODUCT_CATEGORIES[category]['image'] = new_filename
        elif category == 'vulcanization':
            SERVICE_INFO['vulcanization']['image'] = new_filename
        
        return jsonify({
            'success': True,
            'filename': new_filename,
            'url': url_for('static', filename=f'uploads/{new_filename}')
        })
    
    return jsonify({'error': 'Invalid file type'}), 400

@app.route('/api/contact', methods=['POST'])
def contact():
    """Handle contact form submissions"""
    data = request.get_json()
    
    # Here you can add email sending logic or save to database
    # For now, we'll just return success
    
    print(f"New contact request: {data}")
    
    return jsonify({
        'success': True,
        'message': 'Ваша заявка принята! Мы свяжемся с вами в ближайшее время.'
    })

@app.errorhandler(404)
def not_found(error):
    return render_template('index.html'), 404

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)